class CheckScoreResponse {
  final Map data;

  CheckScoreResponse({this.data});

  factory CheckScoreResponse.fromJson(Map json) {
    return CheckScoreResponse(
      data: json,
    );
  }
}
