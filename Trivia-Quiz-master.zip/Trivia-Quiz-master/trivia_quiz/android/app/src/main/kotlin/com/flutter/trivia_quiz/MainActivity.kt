package com.flutter.trivia_quiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
