import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:trivia_quiz/components/decors.dart';
import 'package:trivia_quiz/pages/result.dart';
import 'package:trivia_quiz/services/checkscoreservice.dart';
import 'package:trivia_quiz/services/choicesservice.dart';
import 'package:trivia_quiz/services/questionservice.dart';

class QuizPage extends StatefulWidget {
  @override
  _QuizPageState createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  int questionNumber = 0;
  List questions = [];
  List answers = [];
  List choices = [];
  var questionId = "";

  @override
  void initState() {  
    super.initState(); 
    getAllQuestionss();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: Row(children: [
            GestureDetector(
              child: Icon(Icons.arrow_back),
              onTap: () {
                if (questionNumber > 0) {
                  answers.removeLast();

                  setState(() {
                    questionNumber--;
                    getAllChoices(questions[questionNumber]['id']);
                    questionId = questions[questionNumber]['id'];
                  });
                } else {
                  Navigator.pop(context);
                }
              },
            ),
            Expanded(child: Text("TRIVIA QUIZ", textAlign: TextAlign.center)),
            SizedBox(width: 25)
          ]),
          backgroundColor: Colors.amberAccent,
        ),
        body: questions.length != 0
            ? Column(
                children: [
                  ClipPath(
                    clipper: Decorations(),
                    child: Container(
                      height: 280.0,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.yellow[50],
                      ),
                      child: Stack(children: [
                        Positioned(
                          bottom: 100.0,
                          right: 50.0,
                          top: 50.0,
                          left: 50.0,
                          child: Container(
                              height: 20.0,
                              width: 20.0,
                              child: Center(
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                      "${questions[questionNumber]["question"]}",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Colors.grey,
                                      )),
                                ),
                              ),
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  border: Border.all(
                                      width: 1.0, color: Colors.yellow),
                                  borderRadius: BorderRadius.circular(20.0))),
                        )
                      ]),
                    ),
                  ),
                  SizedBox(height: 10.0),
                  if (choices.length != 0)
                    Wrap(children: [
                      for (var item in choices)
                        buttons("${item["choice"]}", () {
                          pushAnswer(item["id"]);
                        }),
                    ]),
                ],
              )
            : SizedBox());
  }

  getAllQuestionss() async {
    var questionsData = await getQuestions();

    if (questionId == "") {
      questionId = questionsData.data[0]["id"];
      getAllChoices(questionId);
    }

    setState(() {
      questions = questionsData.data;
    });
  }

  Future<void> getAllChoices(questionId) async {
    var choicesData = await getQuestionChoices(questionId);

    setState(() {
      choices = choicesData.data;
    }); 
  }

  pushAnswer(answerId) async {
    answers.add({
      "question": questionId,
      "answer": answerId,
    });

    if (questionNumber != questions.length - 1) {
      setState(() {
        questionNumber++;
        getAllChoices(questions[questionNumber]['id']);
        questionId = questions[questionNumber]['id'];
      });
    } else {
      // End quiz and check scores
      var score = await checkScore({"data": jsonEncode(answers)});
      Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (_) => Result(result: score.data)),
          (route) => false);
    }
  }
}

Widget buttons(String button1, func) {
  String button = button1;

  return Container(
    margin: EdgeInsets.fromLTRB(15.0, 5.0, 10.0, 10.0),
    child: MaterialButton(
        minWidth: 160.0,
        onPressed: func,
        child: Text(button,
            style: TextStyle(
              fontSize: 15.0,
              color: Colors.white,
            )),
        color: Colors.yellowAccent[700],
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0))),
  );
}
