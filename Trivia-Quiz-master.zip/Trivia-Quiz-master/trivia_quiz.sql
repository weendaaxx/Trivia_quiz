-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 13, 2021 at 07:09 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trivia_quiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category`, `created_at`, `updated_at`) VALUES
('c2b41e42-c2a7-4183-a765-2848794c0c8d', 'trivia', '2021-01-12 19:03:10', '2021-01-12 19:03:10');

-- --------------------------------------------------------

--
-- Table structure for table `choices`
--

CREATE TABLE `choices` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `choice` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `choices`
--

INSERT INTO `choices` (`id`, `question_id`, `choice`, `created_at`, `updated_at`) VALUES
('01a8c999-e093-44b8-8d90-d205fcd75f1b', '33b970dc-f4d1-4d7b-b6d3-b3d55641ac3d', 'Cebu', '2021-01-12 21:41:12', '2021-01-12 21:41:12'),
('12a83441-ab8d-474a-9895-cbec2b64cdef', '33b970dc-f4d1-4d7b-b6d3-b3d55641ac3d', 'Makati', '2021-01-12 21:42:13', '2021-01-12 21:42:13'),
('12de06bd-c28e-4053-a6c3-036710674e86', 'a2e6a4d1-a150-4417-bb73-c005a7cbe024', 'Bill Gates', '2021-01-12 19:13:39', '2021-01-12 19:13:39'),
('22eecd0a-3cb1-4dae-82c4-1469324d97f1', '140474cc-9c1d-49f6-9710-269890e5ea78', 'Eagle', '2021-01-12 19:16:23', '2021-01-12 19:16:23'),
('28230c67-0868-4bda-80d6-163e646a02e3', '922e2b77-2448-4a99-a0c5-1357ba76c1e6', 'Leonardo da Vinci', '2021-01-12 21:45:24', '2021-01-12 21:45:24'),
('414ca0fc-75d2-48de-8e80-489d7d0eb2b5', 'a2e6a4d1-a150-4417-bb73-c005a7cbe024', 'Steve Jobs', '2021-01-12 19:14:27', '2021-01-12 19:14:27'),
('4479f595-88ac-4ad4-8ec2-4ad9942c1cd1', '7c05fc06-9f48-40a2-9fb8-53d81838fb5b', 'Emilio Aguinaldo', '2021-01-12 19:07:09', '2021-01-12 19:07:09'),
('44e350b6-241f-4ee6-a935-1a82115fd995', 'a2e6a4d1-a150-4417-bb73-c005a7cbe024', 'Mark Zuckerberg', '2021-01-12 19:12:37', '2021-01-12 19:12:37'),
('6a2843ee-bcdd-4017-8c12-25841e513a9d', '922e2b77-2448-4a99-a0c5-1357ba76c1e6', 'Isaac Newton', '2021-01-12 21:44:53', '2021-01-12 21:44:53'),
('6ab87045-32e5-4754-9d4f-34153a841591', '33b970dc-f4d1-4d7b-b6d3-b3d55641ac3d', 'Manila', '2021-01-12 21:40:32', '2021-01-12 21:40:32'),
('6ec99593-3db3-4ea1-919d-5736d5e58efa', '140474cc-9c1d-49f6-9710-269890e5ea78', 'Bayawak', '2021-01-12 19:17:14', '2021-01-12 19:17:14'),
('6eff1d29-2ef5-4cb5-9078-5bbed63901db', '7c05fc06-9f48-40a2-9fb8-53d81838fb5b', 'Andress Bonifacio', '2021-01-12 19:08:16', '2021-01-12 19:08:16'),
('72428403-e6e9-4472-b813-d8f537396fac', '7c05fc06-9f48-40a2-9fb8-53d81838fb5b', 'Antonio Luna', '2021-01-12 19:10:55', '2021-01-12 19:10:55'),
('73a100e1-7093-46cd-8812-84620b742400', '922e2b77-2448-4a99-a0c5-1357ba76c1e6', 'Pablo Picaso', '2021-01-12 21:46:16', '2021-01-12 21:46:16'),
('956b2893-0032-4123-85c1-5a745400216a', '140474cc-9c1d-49f6-9710-269890e5ea78', 'Goat', '2021-01-12 19:17:35', '2021-01-12 19:17:35'),
('99c86fc5-dc60-443e-9b25-1cba9279019b', '7c05fc06-9f48-40a2-9fb8-53d81838fb5b', 'Manuel Quezon', '2021-01-12 19:09:00', '2021-01-12 19:09:00'),
('a3d36426-426e-47cc-b727-de72fad5de61', '140474cc-9c1d-49f6-9710-269890e5ea78', 'Carabao', '2021-01-12 19:16:17', '2021-01-12 19:16:17'),
('d6ba2403-7580-40bd-8995-50f834b30fae', '33b970dc-f4d1-4d7b-b6d3-b3d55641ac3d', 'Davao', '2021-01-12 21:40:43', '2021-01-12 21:40:43'),
('d8d0388d-6a6d-4b05-b38e-61b2d3717cdf', '922e2b77-2448-4a99-a0c5-1357ba76c1e6', 'Vincent Van Goh', '2021-01-12 21:44:25', '2021-01-12 21:44:25'),
('dc17130f-2690-45a7-9bc3-3a25c48108da', 'a2e6a4d1-a150-4417-bb73-c005a7cbe024', 'Larry page', '2021-01-12 19:13:53', '2021-01-12 19:13:53');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2021_01_08_002845_create_categories_table', 1),
(4, '2021_01_08_012155_create_questions_table', 1),
(5, '2021_01_08_024002_create_choices_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hint` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `category_id`, `question`, `hint`, `answer`, `created_at`, `updated_at`) VALUES
('140474cc-9c1d-49f6-9710-269890e5ea78', 'c2b41e42-c2a7-4183-a765-2848794c0c8d', 'What is the national animal of the Philippines?', '1', 'a3d36426-426e-47cc-b727-de72fad5de61', '2021-01-12 19:16:10', '2021-01-12 19:18:00'),
('33b970dc-f4d1-4d7b-b6d3-b3d55641ac3d', 'c2b41e42-c2a7-4183-a765-2848794c0c8d', 'What is the capital city of the Philippines?', '1', '6ab87045-32e5-4754-9d4f-34153a841591', '2021-01-12 21:40:20', '2021-01-12 21:42:33'),
('7c05fc06-9f48-40a2-9fb8-53d81838fb5b', 'c2b41e42-c2a7-4183-a765-2848794c0c8d', 'Who was the first president of the Phillippines?', '1', '4479f595-88ac-4ad4-8ec2-4ad9942c1cd1', '2021-01-12 19:06:48', '2021-01-12 19:18:12'),
('922e2b77-2448-4a99-a0c5-1357ba76c1e6', 'c2b41e42-c2a7-4183-a765-2848794c0c8d', 'Who painted Mona Lisa?', '1', '28230c67-0868-4bda-80d6-163e646a02e3', '2021-01-12 21:44:11', '2021-01-12 21:46:22'),
('a2e6a4d1-a150-4417-bb73-c005a7cbe024', 'c2b41e42-c2a7-4183-a765-2848794c0c8d', 'Who created Facebook?', '1', '44e350b6-241f-4ee6-a935-1a82115fd995', '2021-01-12 19:12:27', '2021-01-12 19:18:27');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
('7ebbb271-cee6-4f77-9611-2d4e00ff668f', 'wendax', 'wendax@gmail.com', NULL, '$2y$10$4QJ6753b6bdWhSyJDOWPF.KvVohTHr1yrIdlTHAtpa0gvt4L6yMVO', NULL, '2021-01-12 18:55:07', '2021-01-12 18:55:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `choices`
--
ALTER TABLE `choices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `choices_question_id_foreign` (`question_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `questions_category_id_foreign` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `choices`
--
ALTER TABLE `choices`
  ADD CONSTRAINT `choices_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
