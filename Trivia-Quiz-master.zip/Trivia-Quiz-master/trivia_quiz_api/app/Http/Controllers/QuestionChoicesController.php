<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Question;

class QuestionChoicesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id)
    {
        //
        $question = Question::find($id);
        if ($question == NULL) {
            return response()->json(array(
                "message" => "Question not found!",
            ), 404);
        }

        return $question->choices()
        ->select('id', 'choice')->get();
    }
}
