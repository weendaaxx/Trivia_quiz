import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';

import 'package:trivia_quiz/jsonmodels/jsonResponse.dart';
import 'package:trivia_quiz/services/config.dart';


Future<JsonResponse> getQuestionChoices(id) async {
  var res = await http.get("$API_URL/questions/$id/choices");

  if (res.statusCode == 200 || res.statusCode == 404) {
    return JsonResponse.fromJson(jsonDecode(res.body));
  } else {
    throw Exception("Error Occured");
  }
}


Future<JsonResponse> getChoices() async {
  var res = await http.get("$API_URL/choices");

  if (res.statusCode == 200 || res.statusCode == 404) {
    return JsonResponse.fromJson(jsonDecode(res.body));
  } else {
    throw Exception("Error Occured");
  }
}


Future<JsonResponse> getChoice(String id) async {
  var res = await http.get("$API_URL/choices/$id");

  if (res.statusCode == 200 || res.statusCode == 404) {
    return JsonResponse.fromJson(jsonDecode(res.body));
  } else {
    throw Exception("Error Occured");
  }
}
