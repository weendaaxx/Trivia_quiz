<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminController extends Controller
{
    //
    public function login() {
        return view('layouts.login');
    }
    
    public function admin() {
        return view('layouts.admin');
    }

    public function validateAdmin(){}
}
