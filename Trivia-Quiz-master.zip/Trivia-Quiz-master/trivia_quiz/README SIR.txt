git bash here
-run
flutter pub get