<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Question;
use App\Models\Category;
use App\Models\Choice;

class ScoreController extends Controller
{
    public function store(Request $request)
    {
        $data = [
            "total" => 0,
            "score" => 0,
            "category" => "",
            "results" => []
        ];


        $requestData = json_decode($request->data);

        try {
            //code...
            $data["total"] = sizeof($requestData);

    
            $count = 0;
    
            foreach ($requestData as $key => $value) {

                $q = Question::find($value->question);
    
                array_push($data['results'], [
                    "result" => ($value->answer == $q->answer),
                    "hint" => $q->hint,
                    "question" => $q->question,
                    "answer" => Choice::find($q->answer)->choice,
                    "your_answer" => Choice::find($value->answer)->choice,
                ]);


                if(($value->answer == $q->answer)){
                    $count++;                   
                }
                if($data['category'] == ""){
                    $data['category'] = Category::find($q->category_id)->category;
                }
            }

            // Score
            $data['score'] = $count;

        } catch (\Throwable $th) {
            //throw $th;
        }
            
        
        return $data;
    }
}
