import 'package:http/http.dart' as http;
import 'package:trivia_quiz/jsonmodels/checkscoreResponse.dart';
import 'dart:convert';
import 'dart:async';

import 'package:trivia_quiz/services/config.dart';

Future<CheckScoreResponse> checkScore(data) async {
  var res = await http.post("$API_URL/checkscore", body: data);

  if (res.statusCode == 200 || res.statusCode == 404) {
    return CheckScoreResponse.fromJson(jsonDecode(res.body));
  } else {
    throw Exception("Error Occured"); 
  }
}
