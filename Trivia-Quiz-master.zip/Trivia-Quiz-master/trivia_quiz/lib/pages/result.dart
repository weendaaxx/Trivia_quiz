import 'package:flutter/material.dart';
import 'package:trivia_quiz/components/decors.dart';

class Result extends StatefulWidget{
  
  final result;


  Result({this.result});

  @override
  _ResultState createState() => _ResultState();
}

class _ResultState extends State<Result> {
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text("TRIVIA QUIZ"),       
        centerTitle: true,
        backgroundColor: Colors.amberAccent,
      ),
      body: Column(
        children: [
          Stack(
            children: [
              ClipPath(
                  clipper: Decorations(),
                  child: Container(
                  height: 280.0,
                  width: double.infinity,
                  child: Center(
                      child: 
                      Text(
                      (widget.result['total'] * 0.7 < widget.result['score'])?
                        "Congrats!! your score is ${widget.result['score']}/${widget.result['total']}"
                      : "Sorry!! your score is ${widget.result['score']}/${widget.result['total']}",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 20.0,
                        color: Colors.grey,
                      )
                      ),
                    ),
                  decoration: BoxDecoration(
                    color: Colors.yellow[200],
                  ),
                  
                ),
              ),
            ],
          ),
          SizedBox(height: 50.0),
          Container(
            child: Text("TRY AGAIN?",
            style: TextStyle(
              fontSize: 20.0,
              fontWeight: FontWeight.bold,
              color: Colors.yellowAccent[700],
            ),)
          ),
          Row(
            children: [
              buttons("YES", (){
                Navigator.pushNamed(context, "/quiz");
              }),
              buttons("NO", (){
                Navigator.pushNamed(context, "/");
              })
            ],
          )

        ],
      ),
    );
  }}
  
Widget buttons(String buton, func){
  String button = buton;

 return Container(
     margin: EdgeInsets.fromLTRB(50.0, 20.0, 5.0, 10.0),
      child: MaterialButton(
        minWidth: 120.0,
        onPressed: func,
        child: Text(button,
          style: TextStyle(
            fontSize: 15.0,
            color: Colors.white,
          )
        ),
        color: Colors.yellowAccent[700],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0)
          )
        ),
    );
}

