<?php

namespace App\Http\Controllers;

use GuzzleHttp\Middleware;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Models\Question;

class QuestionController extends Controller
{

    public function __construct()
    {
        $this->middleware('jwt-check', ["except" => ["index", "show"]]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return DB::table('questions')->get();
        // ->select('id', 'subject_id', 'note')
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $validator = Validator::make($request->all(), [
            'category_id' => 'required',
            'question' => 'required',
            'hint' => 'required',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            $err = array(
                'category_id' => $errors->first('category_id'),
                'question' => $errors->first('question'),
                'hint' => $errors->first('hint'),
            );

            return response()->json(array(
                'message' => 'Cannot process request',
                'errors' => $err
            ), 422);
        }

        $question = new Question;
        $question->category_id = $request->input("category_id");
        $question->question = $request->input("question");
        $question->answer = $request->input("answer");
        $question->hint = $request->input("hint");
        $question->save();

        return response()->json(array(
            "message" => "Question created Successful",
            "question" => $question
        ), 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $question = Question::find($id);
        if ($question == NULL) {
            return response()->json(array(
                "message" => "Question not found!",
            ), 404);
        }

        return response()->json(array($question), 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $question = Question::find($id);
        if ($question == NULL) {
            return response()->json(array(
                "message" => "Question not found!",
            ), 404);
        }

        if ($request->has('question')){
            $question->question = $request->input('question');
        }
        if ($request->has('answer')){
            $question->answer = $request->input('answer');
        }
        if ($request->has('hint')){
            $question->hint = $request->input('hint');
        }
        $question->save();

        return response()->json(array(
            "message" => "Question is updated!",
        ));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $question = Question::find($id);
        if ($question == NULL) {
            return response()->json(array(
                "message" => "Question not found!",
            ), 404);
        }
        
        $question->delete();

        return response()->json(array(
            "message" => "Question is deleted!",
        ));
    }
}
