import 'package:flutter/material.dart';
import 'package:trivia_quiz/components/decors.dart';

class Homepage extends StatelessWidget{
  
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text("TRIVIA QUIZ"),       
        centerTitle: true,
        backgroundColor: Colors.amberAccent,
      ),
      body: Column(
        children: [
          Stack(
            children: [ 
              ClipPath(
                  clipper: Decorations(),
                  child: Container(
                  height: 280.0,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.yellow[200],
                  ),
                  child: Container(
                    width: 100,
                    child: Image(
                      image: AssetImage("assets/quiz3.png"),
                      // fit: BoxFit.cover
                    ),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 30.0),
          Container(
            child: Text("ARE YOU READY?",
            style: TextStyle(
              fontSize: 20.0,
              fontWeight: FontWeight.bold,
              color: Colors.yellowAccent[700],
            ),)
          ),
          SizedBox(height: 70.0),
          FlatButton(
            padding: EdgeInsets.fromLTRB(30.0, 10.0, 30.0, 10.0),
            onPressed: (){
              Navigator.pushNamed(context, "/quiz");
            },
            child: Text("GAME",
            style: TextStyle(
              fontSize: 20.0,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            )),
            color: Colors.yellowAccent[700],
          )
        ],
      ),
    );
  }}
  


