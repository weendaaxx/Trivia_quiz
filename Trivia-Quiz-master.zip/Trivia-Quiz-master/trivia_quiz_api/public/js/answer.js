// Get answers
async function getAnswers(id, selectedId = null) {
    answers = [];
    $("#answers-list").html("");
    $("#answers-option").text("");

    if(selectedId  == null){
        var a = document.createElement("option");
        
        $(a).attr("Selected", "");
        $(a).attr("disabled", "");
        $(a).append("Select correct answer");
        $("#answers-option").append(a);
    }

    await $.ajax({
        type: "get",
        url: "api/questions/" + id + "/choices",
        success: function (response) {
            answers = response;

            answers.forEach(element => {

                var a = document.createElement("li");
                var b = document.createElement("div");
                var c = document.createElement("div");
                var d1 = document.createElement("div");
                var d2 = document.createElement("div");
                var e = document.createElement("div");
                var f = document.createElement("h5");
                var h = document.createElement("button");

                $(b).addClass("card p-2 crv-8 mt-2");
                $(c).addClass("row");
                $(d1).addClass("col-md-6 display-center");
                $(d2).addClass("col-md-6");
                $(e).addClass("actions float-right");
                $(f).addClass("w-100 text-capitalize");
                $(h).addClass("btn btn-danger ion-android-delete ml-1 ans-delete");
                $(h).attr("data", element['id']);

                $(a).append(b);
                $(b).append(c);
                $(c).append(d1);
                $(c).append(d2);
                $(d1).append(f);
                $(d2).append(e);
                $(e).append(h);
                $(f).append(element['choice']);

                $('#answers-list').append(a);




                var a = document.createElement("option");

                if(selectedId == element['id']){
                    $(a).attr("selected", "");
                }

                $(a).attr("value", element['id']);
                $(a).append(element['choice']);

                $("#answers-option").append(a);
            });
        }
    });
}


// Create answer
async function newAnswer(id, answer) {
    await $.ajax({
        url: "api/choices",
        type: "post",
        headers: { "Authorization": auth_token_type + " " + auth_token },
        data: {
            "question_id": id,
            "choice": answer
        },
        success: function (e) {
            console.log(e);
            getAnswers(id);
            $("#answer_input").val("");
        },
        error: function (e) {
            var resMessage = e.responseJSON['message'];
            var resErrors = e.responseJSON['errors'];

            errorHandler(resMessage, resErrors);
        }
    });
}

// Delete answer
async function delAnswer(id) {
    await $.ajax({
        url: "api/choices/" + id,
        type: "delete",
        headers: { "Authorization": auth_token_type + " " + auth_token },
        success: function (e) {
            getAnswers($("#question-id").val());
        },
        error: function (e) {
            var resMessage = e.responseJSON['message'];

            $("#error").removeClass("display-none");
            $("#error").html("");
            $("#error").append(resMessage);
        }
    });
}