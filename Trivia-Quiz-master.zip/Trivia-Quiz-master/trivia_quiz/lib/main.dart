import 'package:flutter/material.dart';
import 'package:trivia_quiz/pages/home.dart';
import 'package:trivia_quiz/pages/quiz.dart';
import 'package:trivia_quiz/pages/result.dart';

void main()=> runApp(MaterialApp(
   debugShowCheckedModeBanner: false,
   initialRoute: "/",
   routes: {
     "/": (_) => Homepage(),
     "/quiz": (_) => QuizPage(),  
     "/result": (_) => Result(),
   }, 
)
);
