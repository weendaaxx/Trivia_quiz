<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;

class CategoryQuestionsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id)
    {
        //
        $category = Category::find($id);
        if ($category == NULL) {
            return response()->json(array(
                "message" => "Category not found!",
            ), 404);
        }

        return $category->questions()->get();
    }
}
