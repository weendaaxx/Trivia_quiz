class JsonResponse {
  final List data;

  JsonResponse({this.data});

  factory JsonResponse.fromJson(json) {
    try {
      return JsonResponse(
        data: json,
      );
    } catch (e) {
      print(json['message']);
      return JsonResponse(
        data: [],
      );
    }
  }
}