@extends('templates.template')

@section('content')
<div class="container text-center display-center">
    <div class="row w-100">
        <div class="col-md-4 offset-md-4">
            <h3 class="text-bold text-white">
                Trivia Quiz
            </h3>
            
            <form action="#" method="post" id="login-form" class="form-group mt-4">
                <input type="email" name="email" id="email" class="form-control" required placeholder="Email">
                <input type="password" name="password" id="password" class="form-control mt-2" required placeholder="Password">
                <button type="submit" class="btn btn-primary btn-block btn-lg mt-3">Login</button>
            </form>
            <div class="col bg-warning crv-8 px-3 py-2 mt-4 display-none" id="error"></div>
        </div>
    </div>
</div>
@endsection


@section('custom-script')
<script>
    $('body').addClass("loginpage trivia-quiz-bg");
    $('#login-form').on('submit', function (e) {
        e.preventDefault();

        $.ajax({
            url: "api/auth/login",
            headers: {"X-CSRF-TOKEN": $("meta[name='csrf-token']").attr('content')},
            type: "post",
            data: {
                "email": $("#login-form #email").val(),
                "password": $("#login-form #password").val(),
            },
            success:function (e){
                $("#error").addClass("display-none");
                sessionStorage.setItem("auth_token_type", e.token_type);
                sessionStorage.setItem("auth_token", e.access_token);
                window.open("admin", "_self");
            },
            error:function (e){
                if(e.responseJSON.error != undefined){
                    $("#error").removeClass("display-none");
                    $("#error").text(e.responseJSON.error);
                }
            }
        });
    });
</script>
@endsection


