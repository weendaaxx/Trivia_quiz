<?php

namespace App\Http\Controllers;

use GuzzleHttp\Middleware;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Models\Category;

class CategoryController extends Controller
{

    public function __construct()
    {
        $this->middleware('jwt-check', ["except" => ["index", "show"]]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return DB::table('categories')->get();
        // ->select('id', 'subject_id', 'note')
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $validator = Validator::make($request->all(), [
            'category' => 'required',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            $err = array(
                'category' => $errors->first('category'),
            );

            return response()->json(array(
                'message' => 'Cannot process request',
                'errors' => $err
            ), 422);
        }

        $category = new Category;
        $category->category = $request->input("category");
        $category->save();

        return response()->json(array(
            "message" => "Category created Successful",
            "category" => $category
        ), 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $category = Category::find($id);
        if ($category == NULL) {
            return response()->json(array(
                "message" => "Category not found!",
            ), 404);
        }

        return response()->json(array($category), 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $category = Category::find($id);
        if ($category == NULL) {
            return response()->json(array(
                "message" => "Category not found!",
            ), 404);
        }

        if ($request->has('category')){
            $category->category = $request->input('category');
        }
        $category->save();

        return response()->json(array(
            "message" => "Category is updated!",
        ));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $category = Category::find($id);
        if ($category == NULL) {
            return response()->json(array(
                "message" => "Category not found!",
            ), 404);
        }
        
        $category->delete();

        return response()->json(array(
            "message" => "Category is deleted!",
        ));
    }
}
