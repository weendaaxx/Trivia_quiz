<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand-md navbar-dark trivia-quiz-bg">
        <div class="container">
            <h1 class="navbar-brand font-weight-bold">Trivia Quiz</h1>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ml-auto">
                    <a href="#" class="nav-item nav-link prio-nav active mx-3" id="question-nav">Questions</a>
                    <a href="#" class="nav-item nav-link prio-nav mx-3" id="category-nav">Categories</a>
                    <a href="#" class="nav-item nav-link mx-3 btn btn-danger text-white" id="logout-btn">Logout</a>
                </div>
            </div>
        </div>
    </nav>
    <div class="container">
        <div class="row w-100 mt-5 mx-0 ">

            
            <div class="col-md-6 offset-md-3 bg-light p-3 crv-8 display-none" id="category-section">
                <h3>
                    Categories
                </h3>
                <hr>

                <div class="row">
                    <div class="col-md-6">


                        
                        <form action="#" id="newCategory" method="post" class="form-group">
                            <input type="text" name="newCategory_input" id="newCategory_input" class="form-control" required placeholder="New category">
                            <button type="submit" class="btn btn-success ion-android-create form-control mt-1"> Create</button>
                        </form>
                    </div>
                    <div class="col-md-6">
                        
                        
                        
                        <form action="#" id="editCategory" method="post" class="form-group">
                            <input type="text" name="editCategory_input" id="editCategory_input" class="form-control" disabled required placeholder="Edit category">
                            <button type="submit" class="btn btn-info ion-android-create form-control mt-1" id="editCategory_btn" disabled> Update</button>
                        </form>
                    </div>
                </div>



                
                <ul class="list-unstyled mt-3" id="categories-list"></ul>
            </div>
            


            
            <div class="col-md-6 offset-md-3 bg-light p-3 crv-8 mb-5" id="question-section">
                <h3>
                    Questions
                </h3>
                <hr>

                <select name="categories-option" id="categories-option" class="form-control text-capitalize">
                    <option value="" Selected disabled>Select Category</option>
                </select>
                
                
                <div class="row mt-2">
                    <div class="col-md-6">
                        <select name="questions-option" id="questions-option" class="form-control text-capitalize" disabled>
                            <option value="" Selected disabled>Select Question</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <button class="btn btn-success btn-block ion-android-create" disabled id="newQuestion-btn"> New question</button>
                    </div>
                </div>

                <div id="question-preview" class="display-none">
                    <input type="text" name="question-id" id="question-id" class="form-control mt-2" disabled placeholder="Question ID">
                    <input type="text" name="answer-id" id="answer-id" hidden class="form-control mt-2" disabled placeholder="Answer ID">


                    <div id="question-preview-edit">
                        <form action="#" method="post" class="form-group mt-2" id="question-form">
                            <textarea name="question" id="question_textArea" rows="5" class="form-control" required placeholder="Question"></textarea>
                            <textarea name="hint" id="question_textArea_hint" rows="5" class="form-control mt-2" required placeholder="Hint"></textarea>
    
    
    
                            <select name="answers-option" id="answers-option" class="form-control mt-2">
                                <option value="" Selected disabled>Select correct answer</option>
                                
                            </select>
    
    
                            
                            <div class="row mt-2">
                                <div class="col-md display-center">
                                    <div class="">
                                        
                                        <button class="btn btn-info" id="que-edit">Update</button>
                                        <button class="btn btn-danger" id="que-delete">Delete</button>
                                        <button class="btn btn-success mr-auto" id="que-create">Publish</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
    
    
    
                    <div id="answers-section">
                            <hr>
            
                            
                            <form action="#" method="post" class="form-inline mt-2" id="answer-form">
                                <div class="mx-auto">
                                    <input type="text" name="answer_input" id="answer_input" class="form-control" disabled placeholder="answer">
                                    <button class="btn btn-success ion-android-create" id="answer_btn" disabled> New answer</button>
                                </div>
                            </form>
            
            
            
                            
                            <ul class="list-unstyled mt-3" id="answers-list">
                                
                            </ul>
                        </div>
                    </div>
                </div>



            <div class="col-md-6 offset-md-3 bg-warning crv-8 px-3 py-2 mt-2 text-danger display-none" id="error"></div>

        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom-script'); ?>
    <script>
        // Variables
        var auth_token = null;
        var auth_token_type = null;
        var categories = [];
        var questions = [];
        var answers = [];
        var edit_category = "";

        // Navigation
        $(".prio-nav").on("click", function () {
            $("#error").addClass("display-none");

            if(this.id == "question-nav"){
                $("#question-nav").addClass("active");
                $("#category-nav").removeClass("active");
                $("#question-section").removeClass("display-none");
                $("#category-section").addClass("display-none");
            }else{
                $("#question-nav").removeClass("active");
                $("#category-nav").addClass("active");
                $("#category-section").removeClass("display-none");
                $("#question-section").addClass("display-none");
            }
        });

        
        // Logout
        $("#logout-btn").on('click', function () {
            var auth_token = sessionStorage.getItem("auth_token");
            var auth_token_type = sessionStorage.getItem("auth_token_type");
            $.ajax({
                url: "api/auth/logout",
                type: "post",
                headers: {"Authorization": auth_token_type + " " + auth_token},
            });
            sessionStorage.clear();
        });


        // Validate token
        $(function(){
            getCategories();
            setInterval(function(){
                auth_token = sessionStorage.getItem("auth_token");
                auth_token_type = sessionStorage.getItem("auth_token_type");

                if(auth_token == null){
                    window.open("/", "_self");
                }

                $.ajax({
                    url: "validateAdmin",
                    headers: {"Authorization": auth_token_type + " " + auth_token},
                    error: function(e){
                        window.open("/", "_self");
                    }
                });


            }, 100);
        });
    </script>
    <script src="js/category.js"></script>
    <script src="js/answer.js"></script>
    <script src="js/question.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Trivia-Quiz-master\trivia_quiz_api\resources\views/layouts/admin.blade.php ENDPATH**/ ?>