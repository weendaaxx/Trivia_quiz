// Error Handler
function errorHandler(resMessage, resErrors) {
    $("#error").removeClass("display-none");
    $("#error").html("");
    $("#error").append(resMessage);

    var a = document.createElement("ul");
    $(a).addClass("mt-2 ml-3");

    for (const key in resErrors) {
        if (resErrors[key] != "") {
            var b = document.createElement("li");
            $(b).append(key + ": " + resErrors[key]);
            $(a).append(b);
        }
    }

    $("#error").append(a);
}


// Question panel handler
function questionPanel(type, id = "") {
    $("#question-preview").removeClass("display-none");

    if (type == "new") {
        $("#question-id").val("");
        $("#answer-id").val("");
        $("#question_textArea").val("");
        $("#question_textArea_hint").val("");
        $("#answer_input").attr("disabled", "");
        $("#answer_btn").attr("disabled", "");
        $("#que-edit").addClass("display-none");
        $("#que-delete").addClass("display-none");
        $("#que-delete").addClass("display-none");
        $("#que-create").removeClass("display-none");


        answers = [];
        $("#answers-list").html("");
        $("#answers-option").text("");

        var a = document.createElement("option");

        $(a).attr("Selected", "");
        $(a).attr("disabled", "");
        $(a).append("Select correct answer");
        $("#answers-option").append(a);
    } else {
        $("#question-preview").removeClass("display-none");
        $("#question-id").val(id);
        $("#answer_input").removeAttr("disabled");
        $("#answer_btn").removeAttr("disabled");
        $("#que-edit").removeClass("display-none");
        $("#que-delete").removeClass("display-none");
        $("#que-delete").removeClass("display-none");
        $("#que-create").addClass("display-none");
    }
}


// Begin Category functions
// Get categories
async function getCategories() {
    categories = [];
    $("#categories-list").html("");
    $("#categories-option").text("");

    var a = document.createElement("option");

    $(a).attr("Selected", "");
    $(a).attr("disabled", "");
    $(a).append("Select Category");
    $("#categories-option").append(a);

    await $.ajax({
        type: "get",
        url: "api/categories",
        success: function (response) {
            categories = response;
            categories.forEach(element => {

                var a = document.createElement("li");
                var b = document.createElement("div");
                var c = document.createElement("div");
                var d1 = document.createElement("div");
                var d2 = document.createElement("div");
                var e = document.createElement("div");
                var f = document.createElement("h5");
                var g = document.createElement("button");
                var h = document.createElement("button");

                $(b).addClass("card p-2 crv-8 mt-2");
                $(c).addClass("row");
                $(d1).addClass("col-md-6 display-center");
                $(d2).addClass("col-md-6");
                $(e).addClass("actions float-right");
                $(f).addClass("w-100 text-capitalize");
                $(g).addClass("btn btn-primary ion-android-create cat-edit");
                $(g).attr("data", element['id']);
                $(g).attr("data-val", element['category']);
                $(h).addClass("btn btn-danger ion-android-delete ml-1 cat-delete");
                $(h).attr("data", element['id']);

                $(a).append(b);
                $(b).append(c);
                $(c).append(d1);
                $(c).append(d2);
                $(d1).append(f);
                $(d2).append(e);
                $(e).append(g);
                $(e).append(h);
                $(f).append(element['category']);

                $('#categories-list').append(a);




                var a = document.createElement("option");

                $(a).attr("value", element['id']);
                $(a).append(element['category']);

                $("#categories-option").append(a);
            });
        }
    });
}


// Create category
async function newCategory(category) {
    await $.ajax({
        url: "api/categories",
        type: "post",
        headers: { "Authorization": auth_token_type + " " + auth_token },
        data: {
            "category": category,
        },
        success: function (e) {
            getCategories();
        },
        error: function (e) {
            var resMessage = e.responseJSON['message'];
            var resErrors = e.responseJSON['errors'];

            errorHandler(resMessage, resErrors);
        }
    });
}


// Edit category
async function editCategory(id, category) {
    await $.ajax({
        url: "api/categories/" + id,
        type: "put",
        headers: { "Authorization": auth_token_type + " " + auth_token },
        data: {
            "category": category
        },
        success: function (e) {
            getCategories();
        },
        error: function (e) {
            var resMessage = e.responseJSON['message'];
            var resErrors = e.responseJSON['errors'];

            errorHandler(resMessage, resErrors);
        }
    });
}


// Delete category
async function delCategory(id) {
    await $.ajax({
        url: "api/categories/" + id,
        type: "delete",
        headers: { "Authorization": auth_token_type + " " + auth_token },
        success: function (e) {
            getCategories();
        },
        error: function (e) {
            var resMessage = e.responseJSON['message'];

            $("#error").removeClass("display-none");
            $("#error").html("");
            $("#error").append(resMessage);
        }
    });
}
        // End Category functions