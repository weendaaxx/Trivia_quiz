import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';

import 'package:trivia_quiz/jsonmodels/jsonResponse.dart';
import 'package:trivia_quiz/services/config.dart';


Future<JsonResponse> getCategoryQuestions(id) async {
  var res = await http.get("$API_URL/categories/$id/questions");

  if (res.statusCode == 200 || res.statusCode == 404) {
    return JsonResponse.fromJson(jsonDecode(res.body));
  } else {
    throw Exception("Error Occured");
  }
}


Future<JsonResponse> getQuestions() async {
  var res = await http.get("$API_URL/questions"); 

  if (res.statusCode == 200 || res.statusCode == 404) {
    return JsonResponse.fromJson(jsonDecode(res.body));
  } else {
    throw Exception("Error Occured");
  }
}


Future<JsonResponse> getQuestion(String id) async {
  var res = await http.get("$API_URL/questions/$id");

  if (res.statusCode == 200 || res.statusCode == 404) {
    return JsonResponse.fromJson(jsonDecode(res.body));
  } else {
    throw Exception("Error Occured"); 
  }
}
