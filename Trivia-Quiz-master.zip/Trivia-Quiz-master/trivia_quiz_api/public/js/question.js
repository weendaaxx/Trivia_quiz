

// Begin Question functions
// Get questions
async function getCategoryQuestions(categoryId) {
    questions = [];
    $("#questions-option").text("");

    var a = document.createElement("option");

    $(a).attr("Selected", "");
    $(a).attr("disabled", "");
    $(a).append("Select Question");
    $("#questions-option").append(a);

    await $.ajax({
        type: "get",
        url: "api/categories/" + categoryId + "/questions",
        success: function (response) {
            questions = response;
            questions.forEach(element => {
                var a = document.createElement("option");

                $(a).attr("value", element['id']);
                $(a).append(element['question']);

                $("#questions-option").append(a);
            });

            if (questions.length != 0) {
                $("#questions-option").removeAttr("disabled");
            } else {
                $("#questions-option").attr("disabled", "");
            }
        }
    });
}

async function getQuestion(id) {
    await $.ajax({
        type: "get",
        url: "api/questions/" + id,
        success: function (response) {
            console.log(response[0]);
            $("#question_textArea").val(response[0]['question']);
            $("#question_textArea_hint").val(response[0]['hint']);
            $("#answer-id").val(response[0]['answer']);

            getAnswers(id, response[0]['answer']);
        }
    });
}



// Create question
async function newQuestion(category_id, question, hint) {
    await $.ajax({
        url: "api/questions",
        type: "post",
        headers: { "Authorization": auth_token_type + " " + auth_token },
        data: {
            "category_id": category_id,
            "question": question,
            "hint": hint,
        },
        success: function (e) {
            $("#question-id").val(e["question"]["id"]);
            $("#answer-id").val(e["question"]["answer"]);
            questionPanel("", e["question"]["id"]);
            // getCategories();
        },
        error: function (e) {
            var resMessage = e.responseJSON['message'];
            var resErrors = e.responseJSON['errors'];

            errorHandler(resMessage, resErrors);
        }
    });
}


// Edit category
async function editQuestion(id, data) {
    await $.ajax({
        url: "api/questions/" + id,
        type: "put",
        headers: { "Authorization": auth_token_type + " " + auth_token },
        data: data,
        success: function (e) {
            // getCategories();
            console.log(e);
        },
        error: function (e) {
            var resMessage = e.responseJSON['message'];
            var resErrors = e.responseJSON['errors'];

            errorHandler(resMessage, resErrors);
        }
    });
}


// Delete category
async function delCategory(id) {
    await $.ajax({
        url: "api/categories/" + id,
        type: "delete",
        headers: { "Authorization": auth_token_type + " " + auth_token },
        success: function (e) {
            getCategories();
        },
        error: function (e) {
            var resMessage = e.responseJSON['message'];

            $("#error").removeClass("display-none");
            $("#error").html("");
            $("#error").append(resMessage);
        }
    });
}


// Delete question
async function delQuestion(id) {
    await $.ajax({
        url: "api/questions/" + id,
        type: "delete",
        headers: { "Authorization": auth_token_type + " " + auth_token },
        success: function (e) {
            console.log(e);
            getCategoryQuestions($("#categories-option").val());
        },
        error: function (e) {
            var resMessage = e.responseJSON['message'];

            $("#error").removeClass("display-none");
            $("#error").html("");
            $("#error").append(resMessage);
        }
    });
}
// End Question functions






// Forms and actions
// New category
$("#newCategory").on("submit", function (e) {
    e.preventDefault();
    newCategory($("#newCategory_input").val());
    $("#newCategory_input").val("");
});

// Edit category
$("#categories-list").on("click", ".cat-edit", function () {
    edit_category = $(this).attr("data");
    $("#editCategory_input").removeAttr("disabled");
    $("#editCategory_btn").removeAttr("disabled");
    $("#editCategory_input").val($(this).attr("data-val"));
});

$("#editCategory").on("submit", function (e) {
    e.preventDefault();
    editCategory(edit_category, $("#editCategory_input").val());
    edit_category = "";
    $("#editCategory_input").val("");
    $("#editCategory_input").attr("disabled", "");
    $("#editCategory_btn").attr("disabled", "");
});

// Delete category
$("#categories-list").on("click", ".cat-delete", function () {
    delCategory($(this).attr("data"));
});


// Get questions
$("#categories-option").on("change", function () {
    $("#question-preview").addClass("display-none");
    getCategoryQuestions($(this).val());
    $("#newQuestion-btn").removeAttr("disabled");
});

$("#questions-option").on("change", function () {
    if ($(this).val() != "") {
        questionPanel("", $(this).val());
        getQuestion($(this).val());
    }
});


// Question
$("#question-form").on("submit", function (e) {
    e.preventDefault();
});

// New question
$("#newQuestion-btn").on("click", function () {
    questionPanel("new");
});

$("#que-create").on("click", function () {
    if ($("#question_textArea").val() != "" && $("#question_textArea_hint").val() != "") {
        newQuestion(
            $("#categories-option").val(),
            $("#question_textArea").val(),
            $("#question_textArea_hint").val()
        );

        // getCategories();
        // $("#questions-option").val("Select Question");
        // $("#questions-option").attr("disabled", "");
        // $("#newQuestion-btn").attr("disabled", "");
        // $("#question-preview").addClass("display-none");
    }

});

// Edit questions
$("#que-edit").on("click", function () {
    if ($("#question_textArea").val() != "" && $("#question_textArea_hint").val() != "") {
        console.log($("#answers-option").val());

        var q = $("#question_textArea").val();
        var h = $("#question_textArea_hint").val();

        var data = {
            "question": q,
            "hint": h
        };

        if($("#answers-option").val() != null){
            data['answer'] = $("#answers-option").val();
        }

        editQuestion(
            $("#question-id").val(),
            data
        );
        location.reload();
    }
});

// Delete question
$("#que-delete").on("click", function () {
    delQuestion($("#question-id").val());
    location.reload();
});


// Answers
$("#answer-form").on("submit", function (e) {
    e.preventDefault();
});

$("#answer_btn").on("click", function () {
    newAnswer($("#question-id").val(), $("#answer_input").val());
});


// Delete answer
$("#answers-list").on("click", ".ans-delete", function () {
    delAnswer($(this).attr("data"));
});